if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Login_Params {
    username?: string;
    password?: string;
    showPassword?: boolean;
    errorMessage?: string;
}
import promptAction from "@ohos:promptAction";
import router from "@ohos:router";
class Login extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__username = new ObservedPropertySimplePU('1', this, "username");
        this.__password = new ObservedPropertySimplePU('88888888', this, "password");
        this.__showPassword = new ObservedPropertySimplePU(false, this, "showPassword");
        this.__errorMessage = new ObservedPropertySimplePU('', this, "errorMessage");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Login_Params) {
        if (params.username !== undefined) {
            this.username = params.username;
        }
        if (params.password !== undefined) {
            this.password = params.password;
        }
        if (params.showPassword !== undefined) {
            this.showPassword = params.showPassword;
        }
        if (params.errorMessage !== undefined) {
            this.errorMessage = params.errorMessage;
        }
    }
    updateStateVars(params: Login_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__username.purgeDependencyOnElmtId(rmElmtId);
        this.__password.purgeDependencyOnElmtId(rmElmtId);
        this.__showPassword.purgeDependencyOnElmtId(rmElmtId);
        this.__errorMessage.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__username.aboutToBeDeleted();
        this.__password.aboutToBeDeleted();
        this.__showPassword.aboutToBeDeleted();
        this.__errorMessage.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __username: ObservedPropertySimplePU<string>;
    get username() {
        return this.__username.get();
    }
    set username(newValue: string) {
        this.__username.set(newValue);
    }
    private __password: ObservedPropertySimplePU<string>;
    get password() {
        return this.__password.get();
    }
    set password(newValue: string) {
        this.__password.set(newValue);
    }
    private __showPassword: ObservedPropertySimplePU<boolean>;
    get showPassword() {
        return this.__showPassword.get();
    }
    set showPassword(newValue: boolean) {
        this.__showPassword.set(newValue);
    }
    private __errorMessage: ObservedPropertySimplePU<string>;
    get errorMessage() {
        return this.__errorMessage.get();
    }
    set errorMessage(newValue: string) {
        this.__errorMessage.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Login.ets(13:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.padding(20);
            Column.backgroundColor({ "id": 33554432, "type": 10001, params: [], "bundleName": "com.example.droneStore", "moduleName": "entry" });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create({ "id": 33554441, "type": 10003, params: [], "bundleName": "com.example.droneStore", "moduleName": "entry" });
            Text.debugLine("entry/src/main/ets/pages/Login.ets(14:7)", "entry");
            Text.fontSize(35);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor({ "id": 33554436, "type": 10001, params: [], "bundleName": "com.example.droneStore", "moduleName": "entry" });
            Text.margin({ top: 40, bottom: 5 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 33554449, "type": 20000, params: [], "bundleName": "com.example.droneStore", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Login.ets(19:7)", "entry");
            Image.width('37%');
            Image.height(120);
            Image.objectFit(ImageFit.Cover);
            Image.margin({ top: 10 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create({ "id": 33554451, "type": 10003, params: [], "bundleName": "com.example.droneStore", "moduleName": "entry" });
            Text.debugLine("entry/src/main/ets/pages/Login.ets(24:7)", "entry");
            Text.fontSize(18);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor({ "id": 33554436, "type": 10001, params: [], "bundleName": "com.example.droneStore", "moduleName": "entry" });
            Text.margin({ top: 40, bottom: 30 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: { "id": 33554445, "type": 10003, params: [], "bundleName": "com.example.droneStore", "moduleName": "entry" } });
            TextInput.debugLine("entry/src/main/ets/pages/Login.ets(31:7)", "entry");
            TextInput.width('80%');
            TextInput.height(50);
            TextInput.type(InputType.Normal);
            TextInput.onChange((value: string) => {
                this.username = value;
                this.clearError();
            });
            TextInput.margin({ bottom: 20 });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: { "id": 33554442, "type": 10003, params: [], "bundleName": "com.example.droneStore", "moduleName": "entry" } });
            TextInput.debugLine("entry/src/main/ets/pages/Login.ets(42:7)", "entry");
            TextInput.width('80%');
            TextInput.height(50);
            TextInput.type(this.showPassword ? InputType.Normal : InputType.Password);
            TextInput.onChange((value: string) => {
                this.password = value;
                this.clearError();
            });
            TextInput.margin({ bottom: 10 });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Login.ets(52:7)", "entry");
            Row.width('80%');
            Row.justifyContent(FlexAlign.Start);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Checkbox.create();
            Checkbox.debugLine("entry/src/main/ets/pages/Login.ets(53:9)", "entry");
            Checkbox.select(this.showPassword);
            Checkbox.onChange((checked: boolean) => {
                this.showPassword = checked;
            });
        }, Checkbox);
        Checkbox.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create({ "id": 33554444, "type": 10003, params: [], "bundleName": "com.example.droneStore", "moduleName": "entry" });
            Text.debugLine("entry/src/main/ets/pages/Login.ets(58:9)", "entry");
            Text.fontSize(14);
            Text.margin({ left: 8 });
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.errorMessage) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.errorMessage);
                        Text.debugLine("entry/src/main/ets/pages/Login.ets(67:9)", "entry");
                        Text.fontSize(14);
                        Text.fontColor({ "id": 33554433, "type": 10001, params: [], "bundleName": "com.example.droneStore", "moduleName": "entry" });
                        Text.margin({ top: 10 });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel({ "id": 33554438, "type": 10003, params: [], "bundleName": "com.example.droneStore", "moduleName": "entry" }, { type: ButtonType.Capsule });
            Button.debugLine("entry/src/main/ets/pages/Login.ets(74:7)", "entry");
            Button.width('60%');
            Button.height(45);
            Button.margin({ top: 40 });
            Button.backgroundColor({ "id": 33554435, "type": 10001, params: [], "bundleName": "com.example.droneStore", "moduleName": "entry" });
            Button.onClick(() => this.handleLogin());
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create({ "id": 33554437, "type": 10003, params: [], "bundleName": "com.example.droneStore", "moduleName": "entry" });
            Text.debugLine("entry/src/main/ets/pages/Login.ets(81:7)", "entry");
            Text.fontSize(14);
            Text.fontColor({ "id": 33554434, "type": 10001, params: [], "bundleName": "com.example.droneStore", "moduleName": "entry" });
            Text.margin({ top: 20 });
        }, Text);
        Text.pop();
        Column.pop();
    }
    private async handleLogin() {
        if (!this.validateForm())
            return;
        AppStorage.setOrCreate('token', 'mock_token');
        router.replaceUrl({ url: 'pages/Index' });
        promptAction.showToast({
            message: { "id": 33554440, "type": 10003, params: [], "bundleName": "com.example.droneStore", "moduleName": "entry" },
            duration: 2000
        });
    }
    private validateForm(): boolean {
        if (this.username.trim().length === 0) {
            this.errorMessage = { "id": 33554446, "type": 10003, params: [], "bundleName": "com.example.droneStore", "moduleName": "entry" }.toString();
            promptAction.showToast({
                message: { "id": 33554446, "type": 10003, params: [], "bundleName": "com.example.droneStore", "moduleName": "entry" },
                duration: 2000
            });
            return false;
        }
        if (this.password.length < 8) {
            this.errorMessage = { "id": 33554443, "type": 10003, params: [], "bundleName": "com.example.droneStore", "moduleName": "entry" }.toString();
            promptAction.showToast({
                message: { "id": 33554443, "type": 10003, params: [], "bundleName": "com.example.droneStore", "moduleName": "entry" },
                duration: 2000
            });
            return false;
        }
        return true;
    }
    private clearError() {
        this.errorMessage = '';
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Login";
    }
}
if (getPreviewComponentFlag()) {
    storePreviewComponents(1, "Login", new Login(undefined, {}));
    previewComponent();
}
else {
    registerNamedRoute(() => new Login(undefined, {}), "", { bundleName: "com.example.droneStore", moduleName: "entry", pagePath: "pages/Login", pageFullPath: "entry/src/main/ets/pages/Login", integratedHsp: "false", moduleType: "followWithHap" });
}
