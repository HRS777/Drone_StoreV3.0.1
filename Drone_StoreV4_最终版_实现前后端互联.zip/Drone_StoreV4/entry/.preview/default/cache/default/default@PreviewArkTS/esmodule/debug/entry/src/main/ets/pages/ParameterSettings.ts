if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ParameterSettings_Params {
    parameters?: FlightParameters;
    isModified?: boolean;
}
import router from "@ohos:router";
import promptAction from "@ohos:promptAction";
import { Constants } from "@normalized:N&&&entry/src/main/ets/pages/ProductDetail&";
import { DroneDataService, FlightParameters } from "@normalized:N&&&entry/src/main/ets/pages/DroneModel&";
class ParameterSettings extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__parameters = new ObservedPropertyObjectPU(new FlightParameters(), this, "parameters");
        this.__isModified = new ObservedPropertySimplePU(false, this, "isModified");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ParameterSettings_Params) {
        if (params.parameters !== undefined) {
            this.parameters = params.parameters;
        }
        if (params.isModified !== undefined) {
            this.isModified = params.isModified;
        }
    }
    updateStateVars(params: ParameterSettings_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__parameters.purgeDependencyOnElmtId(rmElmtId);
        this.__isModified.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__parameters.aboutToBeDeleted();
        this.__isModified.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __parameters: ObservedPropertyObjectPU<FlightParameters>;
    get parameters() {
        return this.__parameters.get();
    }
    set parameters(newValue: FlightParameters) {
        this.__parameters.set(newValue);
    }
    private __isModified: ObservedPropertySimplePU<boolean>;
    get isModified() {
        return this.__isModified.get();
    }
    set isModified(newValue: boolean) {
        this.__isModified.set(newValue);
    }
    aboutToAppear() {
        const params = DroneDataService.getInstance().getParameters();
        this.parameters = new FlightParameters();
        this.parameters.maxAltitude = params.maxAltitude;
        this.parameters.maxSpeed = params.maxSpeed;
        this.parameters.returnAltitude = params.returnAltitude;
        this.parameters.obstacleAvoidance = params.obstacleAvoidance;
        this.parameters.followMe = params.followMe;
    }
    saveParameters() {
        DroneDataService.getInstance().updateParameters(this.parameters);
        promptAction.showToast({
            message: '参数设置已保存',
            duration: 2000,
        });
        this.isModified = false;
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(35:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Constants.BACKGROUND_COLOR);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(37:7)", "entry");
            Row.width('100%');
            Row.height(56);
            Row.padding({ left: Constants.PAGE_PADDING_X, right: Constants.PAGE_PADDING_X });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(38:9)", "entry");
            Button.type(ButtonType.Circle);
            Button.backgroundColor(Constants.BACKGROUND_COLOR);
            Button.width(40);
            Button.height(40);
            Button.onClick(() => {
                if (this.isModified) {
                    AlertDialog.show({
                        title: '提示',
                        message: '您有未保存的更改，确定要离开吗？',
                        primaryButton: {
                            value: '取消',
                            action: () => { }
                        },
                        secondaryButton: {
                            value: '离开',
                            action: () => {
                                router.back();
                            }
                        }
                    });
                }
                else {
                    router.back();
                }
            });
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777239, "type": 20000, params: [], "bundleName": "com.example.droneStore", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(39:11)", "entry");
            Image.width(24);
            Image.height(24);
        }, Image);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('参数设置');
            Text.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(68:9)", "entry");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Constants.TEXT_PRIMARY_COLOR);
            Text.margin({ left: 16 });
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(79:7)", "entry");
            Scroll.scrollBar(BarState.Off);
            Scroll.edgeEffect(EdgeEffect.Spring);
            Scroll.layoutWeight(1);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(80:9)", "entry");
            Column.width('100%');
            Column.padding({ left: Constants.PAGE_PADDING_X, right: Constants.PAGE_PADDING_X, top: 16, bottom: 80 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(82:11)", "entry");
            Column.width('100%');
            Column.padding(16);
            Column.backgroundColor(Color.White);
            Column.borderRadius(12);
            Column.margin({ bottom: 12 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('飞行高度限制');
            Text.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(83:13)", "entry");
            Text.fontSize(16);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Constants.TEXT_PRIMARY_COLOR);
            Text.width('100%');
            Text.margin({ bottom: 12 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(90:13)", "entry");
            Row.width('100%');
            Row.padding({ top: 8, bottom: 8 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.parameters.maxAltitude.toString() + ' 米');
            Text.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(91:15)", "entry");
            Text.fontSize(16);
            Text.fontColor(Constants.TEXT_SECONDARY_COLOR);
            Text.width(80);
            Text.textAlign(TextAlign.End);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Slider.create({
                value: this.parameters.maxAltitude,
                min: Constants.MIN_ALTITUDE,
                max: Constants.MAX_ALTITUDE,
                step: 10
            });
            Slider.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(97:15)", "entry");
            Slider.layoutWeight(1);
            Slider.margin({ left: 16, right: 16 });
            Slider.onChange((value: number) => {
                this.parameters.maxAltitude = value;
                this.isModified = true;
            });
        }, Slider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(Constants.MAX_ALTITUDE.toString());
            Text.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(110:15)", "entry");
            Text.fontSize(14);
            Text.fontColor(Constants.TEXT_SECONDARY_COLOR);
            Text.width(40);
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(125:11)", "entry");
            Column.width('100%');
            Column.padding(16);
            Column.backgroundColor(Color.White);
            Column.borderRadius(12);
            Column.margin({ bottom: 12 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('飞行速度限制');
            Text.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(126:13)", "entry");
            Text.fontSize(16);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Constants.TEXT_PRIMARY_COLOR);
            Text.width('100%');
            Text.margin({ bottom: 12 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(133:13)", "entry");
            Row.width('100%');
            Row.padding({ top: 8, bottom: 8 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.parameters.maxSpeed.toString() + ' m/s');
            Text.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(134:15)", "entry");
            Text.fontSize(16);
            Text.fontColor(Constants.TEXT_SECONDARY_COLOR);
            Text.width(80);
            Text.textAlign(TextAlign.End);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Slider.create({
                value: this.parameters.maxSpeed,
                min: Constants.MIN_SPEED,
                max: Constants.MAX_SPEED,
                step: 1
            });
            Slider.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(140:15)", "entry");
            Slider.layoutWeight(1);
            Slider.margin({ left: 16, right: 16 });
            Slider.onChange((value: number) => {
                this.parameters.maxSpeed = value;
                this.isModified = true;
            });
        }, Slider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(Constants.MAX_SPEED.toString());
            Text.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(153:15)", "entry");
            Text.fontSize(14);
            Text.fontColor(Constants.TEXT_SECONDARY_COLOR);
            Text.width(40);
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(168:11)", "entry");
            Column.width('100%');
            Column.padding(16);
            Column.backgroundColor(Color.White);
            Column.borderRadius(12);
            Column.margin({ bottom: 12 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('返航高度设置');
            Text.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(169:13)", "entry");
            Text.fontSize(16);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Constants.TEXT_PRIMARY_COLOR);
            Text.width('100%');
            Text.margin({ bottom: 12 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(176:13)", "entry");
            Row.width('100%');
            Row.padding({ top: 8, bottom: 8 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.parameters.returnAltitude.toString() + ' 米');
            Text.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(177:15)", "entry");
            Text.fontSize(16);
            Text.fontColor(Constants.TEXT_SECONDARY_COLOR);
            Text.width(80);
            Text.textAlign(TextAlign.End);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Slider.create({
                value: this.parameters.returnAltitude,
                min: Constants.MIN_RETURN_ALTITUDE,
                max: Constants.MAX_RETURN_ALTITUDE,
                step: 5
            });
            Slider.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(183:15)", "entry");
            Slider.layoutWeight(1);
            Slider.margin({ left: 16, right: 16 });
            Slider.onChange((value: number) => {
                this.parameters.returnAltitude = value;
                this.isModified = true;
            });
        }, Slider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(Constants.MAX_RETURN_ALTITUDE.toString());
            Text.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(196:15)", "entry");
            Text.fontSize(14);
            Text.fontColor(Constants.TEXT_SECONDARY_COLOR);
            Text.width(40);
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(211:11)", "entry");
            Column.width('100%');
            Column.padding(16);
            Column.backgroundColor(Color.White);
            Column.borderRadius(12);
            Column.margin({ bottom: 24 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('智能功能设置');
            Text.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(212:13)", "entry");
            Text.fontSize(16);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Constants.TEXT_PRIMARY_COLOR);
            Text.width('100%');
            Text.margin({ bottom: 12 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(219:13)", "entry");
            Row.width('100%');
            Row.padding({ top: 12, bottom: 12 });
            Row.justifyContent(FlexAlign.SpaceBetween);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('障碍物感知');
            Text.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(220:15)", "entry");
            Text.fontSize(16);
            Text.fontColor(Constants.TEXT_PRIMARY_COLOR);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(224:15)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Toggle.create({ type: ToggleType.Switch, isOn: this.parameters.obstacleAvoidance });
            Toggle.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(226:15)", "entry");
            Toggle.onChange((isOn: boolean) => {
                this.parameters.obstacleAvoidance = isOn;
                this.isModified = true;
            });
        }, Toggle);
        Toggle.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Divider.create();
            Divider.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(236:13)", "entry");
            Divider.width('100%');
            Divider.height(1);
            Divider.backgroundColor('#E3E3E3');
        }, Divider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(241:13)", "entry");
            Row.width('100%');
            Row.padding({ top: 12, bottom: 12 });
            Row.justifyContent(FlexAlign.SpaceBetween);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('自动跟随');
            Text.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(242:15)", "entry");
            Text.fontSize(16);
            Text.fontColor(Constants.TEXT_PRIMARY_COLOR);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(246:15)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Toggle.create({ type: ToggleType.Switch, isOn: this.parameters.followMe });
            Toggle.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(248:15)", "entry");
            Toggle.onChange((isOn: boolean) => {
                this.parameters.followMe = isOn;
                this.isModified = true;
            });
        }, Toggle);
        Toggle.pop();
        Row.pop();
        Column.pop();
        Column.pop();
        Scroll.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(272:7)", "entry");
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceBetween);
            Row.padding({ left: Constants.PAGE_PADDING_X, right: Constants.PAGE_PADDING_X, bottom: 16 });
            Row.backgroundColor(Color.White);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('重置');
            Button.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(273:9)", "entry");
            Button.width('48%');
            Button.height(50);
            Button.backgroundColor({ "id": 125831127, "type": 10001, params: [], "bundleName": "com.example.droneStore", "moduleName": "entry" });
            Button.fontColor(Constants.TEXT_SECONDARY_COLOR);
            Button.borderWidth(1);
            Button.borderColor('#E3E3E3');
            Button.onClick(() => {
                AlertDialog.show({
                    title: '确认重置',
                    message: '确定要重置所有参数到默认值吗？',
                    primaryButton: {
                        value: '取消',
                        action: () => { }
                    },
                    secondaryButton: {
                        value: '确定',
                        action: () => {
                            this.parameters = new FlightParameters();
                            this.isModified = true;
                        }
                    }
                });
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('保存');
            Button.debugLine("entry/src/main/ets/pages/ParameterSettings.ets(298:9)", "entry");
            Button.width('48%');
            Button.height(50);
            Button.backgroundColor(this.isModified ? Constants.PRIMARY_COLOR : '#CCCCCC');
            Button.fontColor(Color.White);
            Button.enabled(this.isModified);
            Button.onClick(() => {
                this.saveParameters();
            });
        }, Button);
        Button.pop();
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "ParameterSettings";
    }
}
export { Constants };
registerNamedRoute(() => new ParameterSettings(undefined, {}), "", { bundleName: "com.example.droneStore", moduleName: "entry", pagePath: "pages/ParameterSettings", pageFullPath: "entry/src/main/ets/pages/ParameterSettings", integratedHsp: "false", moduleType: "followWithHap" });
