if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Index_Params {
    products?: DroneProduct[];
    currentTabIndex?: number;
    isLoading?: boolean;
    imageUrl?: string;
}
import router from "@ohos:router";
import { ProductItem } from "@normalized:N&&&entry/src/main/ets/common/components/ProductItem&";
import type { ProductItemProps } from "@normalized:N&&&entry/src/main/ets/common/components/ProductItem&";
import { DroneDataService } from "@normalized:N&&&entry/src/main/ets/pages/DroneModel&";
import { Constants } from "@normalized:N&&&entry/src/main/ets/common/constants/Constants&";
import { DroneProduct } from "@normalized:N&&&entry/src/main/ets/pages/DroneModel&";
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__products = new ObservedPropertyObjectPU([], this, "products");
        this.__currentTabIndex = new ObservedPropertySimplePU(0, this, "currentTabIndex");
        this.__isLoading = new ObservedPropertySimplePU(true, this, "isLoading");
        this.__imageUrl = new ObservedPropertySimplePU('http://192.168.43.125:8000/static/images/drone1.png', this, "imageUrl");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Index_Params) {
        if (params.products !== undefined) {
            this.products = params.products;
        }
        if (params.currentTabIndex !== undefined) {
            this.currentTabIndex = params.currentTabIndex;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
        if (params.imageUrl !== undefined) {
            this.imageUrl = params.imageUrl;
        }
    }
    updateStateVars(params: Index_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__products.purgeDependencyOnElmtId(rmElmtId);
        this.__currentTabIndex.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__imageUrl.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__products.aboutToBeDeleted();
        this.__currentTabIndex.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        this.__imageUrl.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __products: ObservedPropertyObjectPU<DroneProduct[]>;
    get products() {
        return this.__products.get();
    }
    set products(newValue: DroneProduct[]) {
        this.__products.set(newValue);
    }
    private __currentTabIndex: ObservedPropertySimplePU<number>;
    get currentTabIndex() {
        return this.__currentTabIndex.get();
    }
    set currentTabIndex(newValue: number) {
        this.__currentTabIndex.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    private __imageUrl: ObservedPropertySimplePU<string>;
    get imageUrl() {
        return this.__imageUrl.get();
    }
    set imageUrl(newValue: string) {
        this.__imageUrl.set(newValue);
    }
    async aboutToAppear() {
        try {
            this.isLoading = true;
            this.products = await DroneDataService.getInstance().getProducts();
        }
        catch (error) {
            console.error('加载产品失败:', error);
            this.products = [];
        }
        finally {
            this.isLoading = false;
        }
    }
    TabBuilder(title: string, index: number, icon: Resource, selectedIcon: Resource, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(34:5)", "entry");
            Column.size({ width: '100%', height: '100%' });
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create(this.currentTabIndex === index ? selectedIcon : icon);
            Image.debugLine("entry/src/main/ets/pages/Index.ets(35:7)", "entry");
            Image.size({ width: 24, height: 24 });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(title);
            Text.debugLine("entry/src/main/ets/pages/Index.ets(37:7)", "entry");
            Text.fontSize(12);
            Text.fontColor(this.currentTabIndex === index ? Constants.PRIMARY_COLOR : Constants.TEXT_SECONDARY_COLOR);
            Text.margin({ top: 4 });
        }, Text);
        Text.pop();
        Column.pop();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Tabs.create({ barPosition: BarPosition.End, index: this.currentTabIndex });
            Tabs.debugLine("entry/src/main/ets/pages/Index.ets(47:5)", "entry");
            Tabs.onChange((index: number) => this.currentTabIndex = index);
            Tabs.width('100%');
            Tabs.height('100%');
        }, Tabs);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create(() => {
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/Index.ets(49:9)", "entry");
                    Column.width('100%');
                    Column.backgroundColor(Constants.BACKGROUND_COLOR);
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/Index.ets(50:11)", "entry");
                    Row.padding({ left: 16, right: 16 });
                    Row.height(56);
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('无人机商店');
                    Text.debugLine("entry/src/main/ets/pages/Index.ets(51:13)", "entry");
                    Text.fontSize(20);
                    Text.fontWeight(FontWeight.Bold);
                    Text.fontColor(Constants.TEXT_PRIMARY_COLOR);
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Blank.create();
                    Blank.debugLine("entry/src/main/ets/pages/Index.ets(56:13)", "entry");
                }, Blank);
                Blank.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Button.createWithChild();
                    Button.debugLine("entry/src/main/ets/pages/Index.ets(58:13)", "entry");
                    Button.type(ButtonType.Circle);
                    Button.size({ width: 40, height: 40 });
                    Button.backgroundColor(Constants.BACKGROUND_COLOR);
                    Button.onClick(() => router.pushUrl({ url: 'pages/ParameterSettings' }));
                }, Button);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create({ "id": 16777227, "type": 20000, params: [], "bundleName": "com.example.droneStore", "moduleName": "entry" });
                    Image.debugLine("entry/src/main/ets/pages/Index.ets(59:15)", "entry");
                    Image.size({ width: 24, height: 24 });
                }, Image);
                Button.pop();
                Row.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Scroll.create();
                    Scroll.debugLine("entry/src/main/ets/pages/Index.ets(70:11)", "entry");
                    Scroll.scrollBar(BarState.Off);
                    Scroll.edgeEffect(EdgeEffect.Spring);
                }, Scroll);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    If.create();
                    if (this.isLoading) {
                        this.ifElseBranchUpdateFunction(0, () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create("加载中...");
                                Text.debugLine("entry/src/main/ets/pages/Index.ets(72:15)", "entry");
                                Text.fontSize(16);
                                Text.margin({ top: 20 });
                            }, Text);
                            Text.pop();
                        });
                    }
                    else if (this.products.length === 0) {
                        this.ifElseBranchUpdateFunction(1, () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Text.create("暂无产品");
                                Text.debugLine("entry/src/main/ets/pages/Index.ets(76:15)", "entry");
                                Text.fontSize(16);
                                Text.margin({ top: 20 });
                            }, Text);
                            Text.pop();
                        });
                    }
                    else {
                        this.ifElseBranchUpdateFunction(2, () => {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                Grid.create();
                                Grid.debugLine("entry/src/main/ets/pages/Index.ets(80:15)", "entry");
                                Grid.columnsTemplate('1fr 1fr');
                                Grid.columnsGap(16);
                                Grid.rowsGap(16);
                                Grid.padding(16);
                            }, Grid);
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                ForEach.create();
                                const forEachItemGenFunction = _item => {
                                    const item = _item;
                                    {
                                        const itemCreation2 = (elmtId, isInitialRender) => {
                                            GridItem.create(() => { }, false);
                                            GridItem.margin({ bottom: 16 });
                                            GridItem.debugLine("entry/src/main/ets/pages/Index.ets(82:19)", "entry");
                                        };
                                        const observedDeepRender = () => {
                                            this.observeComponentCreation2(itemCreation2, GridItem);
                                            {
                                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                    if (isInitialRender) {
                                                        let componentCall = new ProductItem(this, {
                                                            params: {
                                                                product: item,
                                                                onProductClick: (product: DroneProduct) => {
                                                                    router.pushUrl({
                                                                        url: 'pages/ProductDetail',
                                                                        params: { productId: product.id }
                                                                    });
                                                                }
                                                            } as ProductItemProps
                                                        }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 83, col: 21 });
                                                        ViewPU.create(componentCall);
                                                        let paramsLambda = () => {
                                                            return {
                                                                params: {
                                                                    product: item,
                                                                    onProductClick: (product: DroneProduct) => {
                                                                        router.pushUrl({
                                                                            url: 'pages/ProductDetail',
                                                                            params: { productId: product.id }
                                                                        });
                                                                    }
                                                                } as ProductItemProps
                                                            };
                                                        };
                                                        componentCall.paramsGenerator_ = paramsLambda;
                                                    }
                                                    else {
                                                        this.updateStateVarsOfChildByElmtId(elmtId, {
                                                            params: {
                                                                product: item,
                                                                onProductClick: (product: DroneProduct) => {
                                                                    router.pushUrl({
                                                                        url: 'pages/ProductDetail',
                                                                        params: { productId: product.id }
                                                                    });
                                                                }
                                                            } as ProductItemProps
                                                        });
                                                    }
                                                }, { name: "ProductItem" });
                                            }
                                            GridItem.pop();
                                        };
                                        observedDeepRender();
                                    }
                                };
                                this.forEachUpdateFunction(elmtId, this.products, forEachItemGenFunction);
                            }, ForEach);
                            ForEach.pop();
                            Grid.pop();
                        });
                    }
                }, If);
                If.pop();
                Scroll.pop();
                Column.pop();
            });
            TabContent.tabBar({ builder: () => {
                    this.TabBuilder.call(this, '商店', 0, { "id": 16777223, "type": 20000, params: [], "bundleName": "com.example.droneStore", "moduleName": "entry" }, { "id": 16777223, "type": 20000, params: [], "bundleName": "com.example.droneStore", "moduleName": "entry" });
                } });
            TabContent.debugLine("entry/src/main/ets/pages/Index.ets(48:7)", "entry");
        }, TabContent);
        TabContent.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create(() => {
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/Index.ets(115:9)", "entry");
                    Column.width('100%');
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/Index.ets(116:11)", "entry");
                    Row.height(56);
                    Row.padding(16);
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('无人机参数');
                    Text.debugLine("entry/src/main/ets/pages/Index.ets(117:13)", "entry");
                    Text.fontSize(20);
                    Text.fontWeight(FontWeight.Bold);
                    Text.fontColor(Constants.TEXT_PRIMARY_COLOR);
                }, Text);
                Text.pop();
                Row.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Button.createWithLabel('参数设置');
                    Button.debugLine("entry/src/main/ets/pages/Index.ets(125:11)", "entry");
                    Button.width('90%');
                    Button.height(50);
                    Button.backgroundColor(Constants.PRIMARY_COLOR);
                    Button.fontColor(Color.White);
                    Button.onClick(() => router.pushUrl({ url: 'pages/ParameterSettings' }));
                    Button.margin({ top: 20 });
                    Button.width('100%');
                }, Button);
                Button.pop();
                Column.pop();
            });
            TabContent.tabBar({ builder: () => {
                    this.TabBuilder.call(this, '模拟参数', 1, { "id": 16777234, "type": 20000, params: [], "bundleName": "com.example.droneStore", "moduleName": "entry" }, { "id": 16777233, "type": 20000, params: [], "bundleName": "com.example.droneStore", "moduleName": "entry" });
                } });
            TabContent.debugLine("entry/src/main/ets/pages/Index.ets(114:7)", "entry");
        }, TabContent);
        TabContent.pop();
        Tabs.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Index";
    }
}
export { DroneProduct };
registerNamedRoute(() => new Index(undefined, {}), "", { bundleName: "com.example.droneStore", moduleName: "entry", pagePath: "pages/Index", pageFullPath: "entry/src/main/ets/pages/Index", integratedHsp: "false", moduleType: "followWithHap" });
