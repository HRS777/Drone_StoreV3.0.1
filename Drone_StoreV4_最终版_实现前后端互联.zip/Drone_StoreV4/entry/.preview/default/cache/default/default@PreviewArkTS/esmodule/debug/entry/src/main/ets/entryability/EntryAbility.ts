import type AbilityConstant from "@ohos:app.ability.AbilityConstant";
import UIAbility from "@ohos:app.ability.UIAbility";
import type Want from "@ohos:app.ability.Want";
import type window from "@ohos:window";
import hilog from "@ohos:hilog";
export default class EntryAbility extends UIAbility {
    onCreate(want: Want, launchParam: AbilityConstant.LaunchParam) {
        hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onCreate');
    }
    onDestroy() {
        hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onDestroy');
    }
    onWindowStageCreate(windowStage: window.WindowStage) {
        // 主窗口创建完成时调用
        windowStage.loadContent('pages/Login', (err, data) => {
            if (err.code) {
                hilog.error(0x0000, 'testTag', 'Failed to load the content. Cause: %{public}s', JSON.stringify(err) ?? '');
                return;
            }
            hilog.info(0x0000, 'testTag', 'Succeeded in loading the content. Data: %{public}s', JSON.stringify(data) ?? '');
        });
    }
    onWindowStageDestroy() {
        // 主窗口销毁时调用
        hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onWindowStageDestroy');
    }
    onForeground() {
        // Ability 进入前台时调用
        hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onForeground');
    }
    onBackground() {
        // Ability 进入后台时调用
        hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onBackground');
    }
}
// entry/src/main/ets/common/constants/Constants.ets
export class Constants {
    // 颜色常量
    static readonly PRIMARY_COLOR: string = '#0A59F7';
    static readonly BACKGROUND_COLOR: string = '#F1F3F5';
    static readonly TEXT_PRIMARY_COLOR: string = '#182431';
    static readonly TEXT_SECONDARY_COLOR: string = '#5A5A5A';
    // 尺寸常量
    static readonly PAGE_PADDING_X: number = 16;
    static readonly ITEM_SPACE: number = 12;
    // 设置参数范围
    static readonly MIN_ALTITUDE: number = 0;
    static readonly MAX_ALTITUDE: number = 500;
    static readonly MIN_SPEED: number = 0;
    static readonly MAX_SPEED: number = 20;
    static readonly MIN_RETURN_ALTITUDE: number = 30;
    static readonly MAX_RETURN_ALTITUDE: number = 120;
}
