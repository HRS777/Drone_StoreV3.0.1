if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ProductDetail_Params {
    product?: DroneProduct | null;
    isLoading?: boolean;
}
import router from "@ohos:router";
import { DroneDataService } from "@normalized:N&&&entry/src/main/ets/pages/DroneModel&";
import type { DroneProduct } from "@normalized:N&&&entry/src/main/ets/pages/DroneModel&";
import { Constants } from "@normalized:N&&&entry/src/main/ets/common/constants/Constants&";
interface RouteParams {
    productId: number;
}
class ProductDetail extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__product = new ObservedPropertyObjectPU(null, this, "product");
        this.__isLoading = new ObservedPropertySimplePU(true, this, "isLoading");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ProductDetail_Params) {
        if (params.product !== undefined) {
            this.product = params.product;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
    }
    updateStateVars(params: ProductDetail_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__product.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__product.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __product: ObservedPropertyObjectPU<DroneProduct | null>;
    get product() {
        return this.__product.get();
    }
    set product(newValue: DroneProduct | null) {
        this.__product.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    async aboutToAppear() {
        try {
            this.isLoading = true;
            const params = router.getParams() as RouteParams | undefined;
            if (!params?.productId) {
                console.error("无效的产品ID");
                return;
            }
            console.log("Received productId:", params.productId);
            const productData = await DroneDataService.getInstance().getProductById(params.productId);
            if (!productData) {
                console.error("未找到对应产品");
                return;
            }
            this.product = productData;
        }
        catch (error) {
            console.error("加载失败:", error);
        }
        finally {
            this.isLoading = false;
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ProductDetail.ets(43:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Constants.BACKGROUND_COLOR);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 顶部导航栏
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ProductDetail.ets(45:7)", "entry");
            // 顶部导航栏
            Row.width('100%');
            // 顶部导航栏
            Row.height(56);
            // 顶部导航栏
            Row.padding({ left: Constants.PAGE_PADDING_X, right: Constants.PAGE_PADDING_X });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 返回按钮
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/ProductDetail.ets(47:9)", "entry");
            // 返回按钮
            Button.type(ButtonType.Circle);
            // 返回按钮
            Button.backgroundColor(Constants.BACKGROUND_COLOR);
            // 返回按钮
            Button.width(40);
            // 返回按钮
            Button.height(40);
            // 返回按钮
            Button.onClick(() => router.back());
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777239, "type": 20000, params: [], "bundleName": "com.example.droneStore", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/ProductDetail.ets(48:11)", "entry");
            Image.width(24);
            Image.height(24);
        }, Image);
        // 返回按钮
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/ProductDetail.ets(58:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 产品名标题
            Text.create(this.product?.name ?? '产品详情');
            Text.debugLine("entry/src/main/ets/pages/ProductDetail.ets(61:9)", "entry");
            // 产品名标题
            Text.fontSize(18);
            // 产品名标题
            Text.fontWeight(FontWeight.Bold);
            // 产品名标题
            Text.fontColor(Constants.TEXT_PRIMARY_COLOR);
        }, Text);
        // 产品名标题
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/ProductDetail.ets(66:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 分享按钮
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/pages/ProductDetail.ets(69:9)", "entry");
            // 分享按钮
            Button.type(ButtonType.Circle);
            // 分享按钮
            Button.backgroundColor(Color.White);
            // 分享按钮
            Button.width(40);
            // 分享按钮
            Button.height(40);
            // 分享按钮
            Button.onClick(() => {
                console.log('点击了分享按钮，准备跳转');
                router.pushUrl({ url: 'pages/MiniGamePage' });
            });
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777235, "type": 20000, params: [], "bundleName": "com.example.droneStore", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/ProductDetail.ets(70:11)", "entry");
            Image.width(24);
            Image.height(24);
        }, Image);
        // 分享按钮
        Button.pop();
        // 顶部导航栏
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 内容区域
            if (this.isLoading) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ProductDetail.ets(89:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('加载中...');
                        Text.debugLine("entry/src/main/ets/pages/ProductDetail.ets(90:11)", "entry");
                        Text.fontSize(16);
                        Text.fontColor(Constants.TEXT_SECONDARY_COLOR);
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else if (this.product) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Scroll.create();
                        Scroll.debugLine("entry/src/main/ets/pages/ProductDetail.ets(98:9)", "entry");
                        Scroll.scrollBar(BarState.Off);
                        Scroll.edgeEffect(EdgeEffect.Spring);
                        Scroll.layoutWeight(1);
                    }, Scroll);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ProductDetail.ets(99:11)", "entry");
                        Column.width('100%');
                        Column.padding({ bottom: 80 });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 产品图片
                        Image.create(this.product.image);
                        Image.debugLine("entry/src/main/ets/pages/ProductDetail.ets(101:13)", "entry");
                        // 产品图片
                        Image.width('100%');
                        // 产品图片
                        Image.height(280);
                        // 产品图片
                        Image.objectFit(ImageFit.Cover);
                        // 产品图片
                        Image.borderRadius({ bottomLeft: 16, bottomRight: 16 });
                    }, Image);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 标题 + 价格
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/ProductDetail.ets(108:13)", "entry");
                        // 标题 + 价格
                        Row.width('100%');
                        // 标题 + 价格
                        Row.padding({ left: Constants.PAGE_PADDING_X, right: Constants.PAGE_PADDING_X, top: 16, bottom: 8 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.product.name);
                        Text.debugLine("entry/src/main/ets/pages/ProductDetail.ets(109:15)", "entry");
                        Text.fontSize(22);
                        Text.fontWeight(FontWeight.Bold);
                        Text.fontColor(Constants.TEXT_PRIMARY_COLOR);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/ProductDetail.ets(114:15)", "entry");
                    }, Blank);
                    Blank.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('¥' + this.product.price);
                        Text.debugLine("entry/src/main/ets/pages/ProductDetail.ets(116:15)", "entry");
                        Text.fontSize(20);
                        Text.fontWeight(FontWeight.Bold);
                        Text.fontColor(Constants.PRIMARY_COLOR);
                    }, Text);
                    Text.pop();
                    // 标题 + 价格
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 描述
                        Text.create(this.product.description);
                        Text.debugLine("entry/src/main/ets/pages/ProductDetail.ets(125:13)", "entry");
                        // 描述
                        Text.fontSize(16);
                        // 描述
                        Text.fontColor(Constants.TEXT_SECONDARY_COLOR);
                        // 描述
                        Text.margin({ bottom: 16 });
                        // 描述
                        Text.padding({ left: Constants.PAGE_PADDING_X, right: Constants.PAGE_PADDING_X });
                    }, Text);
                    // 描述
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 产品规格
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ProductDetail.ets(132:13)", "entry");
                        // 产品规格
                        Column.width('100%');
                        // 产品规格
                        Column.padding({ left: Constants.PAGE_PADDING_X, right: Constants.PAGE_PADDING_X, top: 16, bottom: 16 });
                        // 产品规格
                        Column.backgroundColor(Color.White);
                        // 产品规格
                        Column.borderRadius(12);
                        // 产品规格
                        Column.margin({ left: Constants.PAGE_PADDING_X, right: Constants.PAGE_PADDING_X });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('产品规格');
                        Text.debugLine("entry/src/main/ets/pages/ProductDetail.ets(133:15)", "entry");
                        Text.fontSize(18);
                        Text.fontWeight(FontWeight.Bold);
                        Text.fontColor(Constants.TEXT_PRIMARY_COLOR);
                        Text.width('100%');
                        Text.margin({ bottom: 12 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        List.create();
                        List.debugLine("entry/src/main/ets/pages/ProductDetail.ets(140:15)", "entry");
                        List.width('100%');
                        List.height(200);
                    }, List);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const spec = _item;
                            {
                                const itemCreation = (elmtId, isInitialRender) => {
                                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                    itemCreation2(elmtId, isInitialRender);
                                    if (!isInitialRender) {
                                        ListItem.pop();
                                    }
                                    ViewStackProcessor.StopGetAccessRecording();
                                };
                                const itemCreation2 = (elmtId, isInitialRender) => {
                                    ListItem.create(deepRenderFunction, true);
                                    ListItem.debugLine("entry/src/main/ets/pages/ProductDetail.ets(142:19)", "entry");
                                };
                                const deepRenderFunction = (elmtId, isInitialRender) => {
                                    itemCreation(elmtId, isInitialRender);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Row.create();
                                        Row.debugLine("entry/src/main/ets/pages/ProductDetail.ets(143:21)", "entry");
                                        Row.alignItems(VerticalAlign.Center);
                                        Row.width('100%');
                                        Row.padding({ top: 6, bottom: 6 });
                                    }, Row);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Image.create({ "id": 16777226, "type": 20000, params: [], "bundleName": "com.example.droneStore", "moduleName": "entry" });
                                        Image.debugLine("entry/src/main/ets/pages/ProductDetail.ets(144:23)", "entry");
                                        Image.width(16);
                                        Image.height(16);
                                        Image.margin({ right: 8 });
                                    }, Image);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Text.create(spec);
                                        Text.debugLine("entry/src/main/ets/pages/ProductDetail.ets(148:23)", "entry");
                                        Text.fontSize(14);
                                        Text.fontColor(Constants.TEXT_SECONDARY_COLOR);
                                    }, Text);
                                    Text.pop();
                                    Row.pop();
                                    ListItem.pop();
                                };
                                this.observeComponentCreation2(itemCreation2, ListItem);
                                ListItem.pop();
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.product.specifications, forEachItemGenFunction);
                    }, ForEach);
                    ForEach.pop();
                    List.pop();
                    // 产品规格
                    Column.pop();
                    Column.pop();
                    Scroll.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ProductDetail.ets(174:9)", "entry");
                        Column.width('100%');
                        Column.layoutWeight(1);
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('产品不存在或加载失败');
                        Text.debugLine("entry/src/main/ets/pages/ProductDetail.ets(175:11)", "entry");
                        Text.fontSize(16);
                        Text.fontColor(Constants.TEXT_SECONDARY_COLOR);
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 底部操作栏
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ProductDetail.ets(185:7)", "entry");
            // 底部操作栏
            Row.width('100%');
            // 底部操作栏
            Row.justifyContent(FlexAlign.SpaceBetween);
            // 底部操作栏
            Row.padding({ left: Constants.PAGE_PADDING_X, right: Constants.PAGE_PADDING_X, top: 8, bottom: 16 });
            // 底部操作栏
            Row.backgroundColor(Color.White);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('加入购物车');
            Button.debugLine("entry/src/main/ets/pages/ProductDetail.ets(186:9)", "entry");
            Button.width('48%');
            Button.height(50);
            Button.backgroundColor({ "id": 125831127, "type": 10001, params: [], "bundleName": "com.example.droneStore", "moduleName": "entry" });
            Button.fontColor(Constants.PRIMARY_COLOR);
            Button.borderWidth(1);
            Button.borderColor(Constants.PRIMARY_COLOR);
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('立即购买');
            Button.debugLine("entry/src/main/ets/pages/ProductDetail.ets(194:9)", "entry");
            Button.width('48%');
            Button.height(50);
            Button.backgroundColor(Constants.PRIMARY_COLOR);
            Button.fontColor(Color.White);
        }, Button);
        Button.pop();
        // 底部操作栏
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "ProductDetail";
    }
}
export { Constants };
registerNamedRoute(() => new ProductDetail(undefined, {}), "", { bundleName: "com.example.droneStore", moduleName: "entry", pagePath: "pages/ProductDetail", pageFullPath: "entry/src/main/ets/pages/ProductDetail", integratedHsp: "false", moduleType: "followWithHap" });
