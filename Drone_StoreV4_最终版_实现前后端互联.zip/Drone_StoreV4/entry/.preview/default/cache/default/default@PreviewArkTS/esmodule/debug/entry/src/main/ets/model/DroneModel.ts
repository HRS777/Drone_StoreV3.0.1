// model/DroneModel.ets
export class DroneProduct {
    id: number;
    name: string;
    price: number;
    image: Resource;
    description: string;
    specifications: string[];
    constructor(id: number, name: string, price: number, image: Resource, description: string, specifications: string[]) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.image = image;
        this.description = description;
        this.specifications = specifications;
    }
}
export class FlightParameters {
    maxAltitude: number = 120;
    maxSpeed: number = 10;
    returnAltitude: number = 50;
    obstacleAvoidance: boolean = true;
    followMe: boolean = false;
    constructor() { }
}
export class DroneDataService {
    private static instance: DroneDataService;
    private products: DroneProduct[] = [];
    private parameters: FlightParameters = new FlightParameters();
    private constructor() {
        this.initProductData();
    }
    static getInstance(): DroneDataService {
        if (!DroneDataService.instance) {
            DroneDataService.instance = new DroneDataService();
        }
        return DroneDataService.instance;
    }
    private initProductData() {
        this.products = [
            new DroneProduct(1, "天空探索者Pro", 7999, { "id": 16777240, "type": 20000, params: [], "bundleName": "com.example.droneStore", "moduleName": "entry" }, "专业级航拍无人机，搭载1英寸CMOS传感器，支持4K/60fps视频录制，最大飞行时间45分钟。", ["最大飞行时间: 45分钟", "最大控制距离: 12公里", "相机: 1英寸CMOS", "视频分辨率: 4K/60fps"]),
            new DroneProduct(2, "灵眸Mini", 3299, { "id": 16777231, "type": 20000, params: [], "bundleName": "com.example.droneStore", "moduleName": "entry" }, "轻便折叠式无人机，重量仅249克，无需注册即可飞行，支持2.7K高清视频。", ["最大飞行时间: 30分钟", "最大控制距离: 4公里", "相机: 1/2.3英寸CMOS", "视频分辨率: 2.7K/30fps"]),
            new DroneProduct(3, "天行者X", 12999, { "id": 16777225, "type": 20000, params: [], "bundleName": "com.example.droneStore", "moduleName": "entry" }, "专业测绘与巡检无人机，搭载RTK高精度定位模块，支持多种负载设备更换。", ["最大飞行时间: 55分钟", "最大控制距离: 15公里", "载重: 2公斤", "定位精度: 厘米级"]),
            new DroneProduct(4, "农飞侠2000", 15999, { "id": 16777229, "type": 20000, params: [], "bundleName": "com.example.droneStore", "moduleName": "entry" }, "农业植保无人机，10L药箱容量，智能规划路线，高效精准喷洒。", ["最大飞行时间: 25分钟", "药箱容量: 10L", "喷洒效率: 40亩/小时", "抗风能力: 5级"]),
        ];
    }
    getProducts(): DroneProduct[] {
        return this.products;
    }
    getProductById(id: number): DroneProduct | undefined {
        return this.products.find(product => product.id === id);
    }
    getParameters(): FlightParameters {
        return this.parameters;
    }
    updateParameters(params: FlightParameters): void {
        this.parameters = params;
    }
}
