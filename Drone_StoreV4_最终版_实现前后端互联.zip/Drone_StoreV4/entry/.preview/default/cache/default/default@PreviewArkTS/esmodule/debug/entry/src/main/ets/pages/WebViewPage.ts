if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface WebViewPage_Params {
    webviewController?: webview.WebviewController;
    url?: string;
}
import webview from "@ohos:web.webview";
import router from "@ohos:router";
interface RouteParams {
    url?: string;
}
class WebViewPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.webviewController = new webview.WebviewController();
        this.__url = new ObservedPropertySimplePU('', this, "url");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: WebViewPage_Params) {
        if (params.webviewController !== undefined) {
            this.webviewController = params.webviewController;
        }
        if (params.url !== undefined) {
            this.url = params.url;
        }
    }
    updateStateVars(params: WebViewPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__url.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__url.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private webviewController: webview.WebviewController;
    private __url: ObservedPropertySimplePU<string>;
    get url() {
        return this.__url.get();
    }
    set url(newValue: string) {
        this.__url.set(newValue);
    }
    aboutToAppear() {
        const params = router.getParams() as RouteParams | undefined;
        this.url = params?.url ?? 'https://www.dji.com/cn';
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/WebViewPage.ets(20:5)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Web.create({ src: this.url, controller: this.webviewController });
            Web.debugLine("entry/src/main/ets/pages/WebViewPage.ets(21:7)", "entry");
            Web.domStorageAccess(true);
            Web.width('100%');
            Web.height('100%');
        }, Web);
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "WebViewPage";
    }
}
export default WebViewPage;
registerNamedRoute(() => new WebViewPage(undefined, {}), "", { bundleName: "com.example.droneStore", moduleName: "entry", pagePath: "pages/WebViewPage", pageFullPath: "entry/src/main/ets/pages/WebViewPage", integratedHsp: "false", moduleType: "followWithHap" });
