interface GeneratedObjectLiteralInterface_1 {
    Title: number;
    Button: number;
    Score: number;
}
interface GeneratedObjectLiteralInterface_2 {
    Background: string;
    Title: string;
    Button: string;
    ButtonText: string;
    Score: string;
}
interface GeneratedObjectLiteralInterface_3 {
    OuterPadding: number;
    ButtonMargin: number;
    TitlePadding: number;
}
interface GeneratedObjectLiteralInterface_4 {
    Button: number;
    GameArea: number;
}
interface GeneratedObjectLiteralInterface_5 {
    Width: number;
    Height: number;
}
interface GeneratedObjectLiteralInterface_6 {
    Drone: number;
    Obstacle: GeneratedObjectLiteralInterface_5;
}
interface GeneratedObjectLiteralInterface_7 {
    FontSize: GeneratedObjectLiteralInterface_1;
    Color: GeneratedObjectLiteralInterface_2;
    Spacing: GeneratedObjectLiteralInterface_3;
    Radius: GeneratedObjectLiteralInterface_4;
    Size: GeneratedObjectLiteralInterface_6;
}
export const GameStyles: GeneratedObjectLiteralInterface_7 = {
    FontSize: ({
        Title: 32,
        Button: 20,
        Score: 18
    } as GeneratedObjectLiteralInterface_1),
    Color: ({
        Background: '#F4F7FA',
        Title: '#1F2D3D',
        Button: '#007DFF',
        ButtonText: '#FFFFFF',
        Score: '#333333'
    } as GeneratedObjectLiteralInterface_2),
    Spacing: ({
        OuterPadding: 24,
        ButtonMargin: 40,
        TitlePadding: 24
    } as GeneratedObjectLiteralInterface_3),
    Radius: ({
        Button: 12,
        GameArea: 12
    } as GeneratedObjectLiteralInterface_4),
    Size: ({
        Drone: 40,
        Obstacle: ({
            Width: 30,
            Height: 100
        } as GeneratedObjectLiteralInterface_5)
    } as GeneratedObjectLiteralInterface_6)
};
