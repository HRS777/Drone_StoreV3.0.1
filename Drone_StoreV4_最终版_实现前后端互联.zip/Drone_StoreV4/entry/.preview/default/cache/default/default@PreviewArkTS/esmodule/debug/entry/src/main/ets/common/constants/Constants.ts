// common/constants/Constants.ets
export class Constants {
    static readonly PRIMARY_COLOR: string = '#0A59F7';
    static readonly BACKGROUND_COLOR: string = '#F1F3F5';
    static readonly TEXT_PRIMARY_COLOR: string = '#182431';
    static readonly TEXT_SECONDARY_COLOR: string = '#5A5A5A';
    static readonly PAGE_PADDING_X: number = 16;
    static readonly ITEM_SPACE: number = 12;
    static readonly MIN_ALTITUDE: number = 0;
    static readonly MAX_ALTITUDE: number = 500;
    static readonly MIN_SPEED: number = 0;
    static readonly MAX_SPEED: number = 20;
    static readonly MIN_RETURN_ALTITUDE: number = 30;
    static readonly MAX_RETURN_ALTITUDE: number = 120;
}
