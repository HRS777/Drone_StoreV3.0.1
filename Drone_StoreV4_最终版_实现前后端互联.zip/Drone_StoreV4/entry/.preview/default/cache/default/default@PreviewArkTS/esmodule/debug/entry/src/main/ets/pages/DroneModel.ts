export class DroneProduct {
    id: number;
    name: string;
    price: number;
    image: string;
    description: string;
    specifications: string[];
    constructor(id: number, name: string, price: number, image: string, description: string, specifications: string[]) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.image = image;
        this.description = description;
        this.specifications = specifications;
    }
}
export class FlightParameters {
    maxAltitude: number = 120;
    maxSpeed: number = 10;
    returnAltitude: number = 50;
    obstacleAvoidance: boolean = true;
    followMe: boolean = false;
    constructor() { }
}
export class DroneDataService {
    private static instance: DroneDataService;
    private products: DroneProduct[] = [];
    private parameters: FlightParameters = new FlightParameters();
    private constructor() {
        this.initProductData();
    }
    static getInstance(): DroneDataService {
        if (!DroneDataService.instance) {
            DroneDataService.instance = new DroneDataService();
        }
        return DroneDataService.instance;
    }
    private initProductData() {
        this.products = [
            new DroneProduct(1, "天空探索者Pro", 7999, "http://192.168.43.125:8000/static/images/drone1.png", "专业级航拍无人机，搭载1英寸CMS传感器，支持4K/60fps视频录制，最大飞行时间45分钟。", ["最大飞行时间: 45分钟", "最大控制距离: 12公里", "相机: 1英寸CMS", "视频分辨率: 4K/60fps"]),
            new DroneProduct(2, "灵眸Mini", 3299, "http://192.168.43.125:8000/static/images/drone2.png", "轻便折叠式无人机，重量仅249克，无需注册即可飞行，支持2.7K高清视频。", ["最大飞行时间: 30分钟", "最大控制距离: 4公里", "相机: 1/2.3英寸CMS", "视频分辨率: 2.7K/30fps"]),
            new DroneProduct(3, "天行者X", 12999, "http://192.168.43.125:8000/static/images/drone3.png", "专业测绘与巡检无人机，搭载RTK高精度定位模块，支持多种负载设备更换。", ["最大飞行时间: 55分钟", "最大控制距离: 15公里", "载重: 2公斤", "定位精度: 厘米级"]),
            new DroneProduct(4, "农飞侠2000", 15999, "http://192.168.43.125:8000/static/images/drone4.png", "农业植保无人机，10L药箱容量，智能规划路线，高效精准喷洒。", ["最大飞行时间: 25分钟", "药箱容量: 10L", "喷洒效率: 40亩/小时", "抗风能力: 5级"]),
        ];
    }
    async getProducts(): Promise<DroneProduct[]> {
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve(this.products);
            }, 500);
        });
    }
    async getProductById(id: number): Promise<DroneProduct | undefined> {
        return new Promise((resolve) => {
            setTimeout(() => {
                const product = this.products.find(p => p.id === id);
                resolve(product);
            }, 300);
        });
    }
    getParameters(): FlightParameters {
        return this.parameters;
    }
    updateParameters(params: FlightParameters): void {
        this.parameters = params;
    }
}
