if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ProductItem_Params {
    params?: ProductItemProps;
    imageUrl?: string;
    imageUrl2?: string;
    imageUrl3?: string;
    imageUrl4?: string;
}
import { DroneProduct } from "@normalized:N&&&entry/src/main/ets/pages/Index&";
import { Constants } from "@normalized:N&&&entry/src/main/ets/common/constants/Constants&";
export { DroneProduct };
export interface ProductItemProps {
    product: DroneProduct;
    onProductClick: (product: DroneProduct) => void;
}
export class ProductItem extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__params = new SynchedPropertyObjectOneWayPU(params.params, this, "params");
        this.__imageUrl = new ObservedPropertySimplePU('http://192.168.43.125:8000/static/images/drone1.png', this, "imageUrl");
        this.__imageUrl2 = new ObservedPropertySimplePU('http://192.168.43.125:8000/static/images/drone2.png', this, "imageUrl2");
        this.__imageUrl3 = new ObservedPropertySimplePU('http://192.168.43.125:8000/static/images/drone3.png', this, "imageUrl3");
        this.__imageUrl4 = new ObservedPropertySimplePU('http://192.168.43.125:8000/static/images/drone4.png', this, "imageUrl4");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ProductItem_Params) {
        if (params.imageUrl !== undefined) {
            this.imageUrl = params.imageUrl;
        }
        if (params.imageUrl2 !== undefined) {
            this.imageUrl2 = params.imageUrl2;
        }
        if (params.imageUrl3 !== undefined) {
            this.imageUrl3 = params.imageUrl3;
        }
        if (params.imageUrl4 !== undefined) {
            this.imageUrl4 = params.imageUrl4;
        }
    }
    updateStateVars(params: ProductItem_Params) {
        this.__params.reset(params.params);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__params.purgeDependencyOnElmtId(rmElmtId);
        this.__imageUrl.purgeDependencyOnElmtId(rmElmtId);
        this.__imageUrl2.purgeDependencyOnElmtId(rmElmtId);
        this.__imageUrl3.purgeDependencyOnElmtId(rmElmtId);
        this.__imageUrl4.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__params.aboutToBeDeleted();
        this.__imageUrl.aboutToBeDeleted();
        this.__imageUrl2.aboutToBeDeleted();
        this.__imageUrl3.aboutToBeDeleted();
        this.__imageUrl4.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __params: SynchedPropertySimpleOneWayPU<ProductItemProps>;
    get params() {
        return this.__params.get();
    }
    set params(newValue: ProductItemProps) {
        this.__params.set(newValue);
    }
    private __imageUrl: ObservedPropertySimplePU<string>;
    get imageUrl() {
        return this.__imageUrl.get();
    }
    set imageUrl(newValue: string) {
        this.__imageUrl.set(newValue);
    }
    private __imageUrl2: ObservedPropertySimplePU<string>;
    get imageUrl2() {
        return this.__imageUrl2.get();
    }
    set imageUrl2(newValue: string) {
        this.__imageUrl2.set(newValue);
    }
    private __imageUrl3: ObservedPropertySimplePU<string>;
    get imageUrl3() {
        return this.__imageUrl3.get();
    }
    set imageUrl3(newValue: string) {
        this.__imageUrl3.set(newValue);
    }
    private __imageUrl4: ObservedPropertySimplePU<string>;
    get imageUrl4() {
        return this.__imageUrl4.get();
    }
    set imageUrl4(newValue: string) {
        this.__imageUrl4.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/common/components/ProductItem.ets(19:5)", "entry");
            Column.padding(12);
            Column.backgroundColor(Color.White);
            Column.borderRadius(16);
            Column.shadow({ radius: 6, color: '#22000000', offsetX: 0, offsetY: 2 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create(this.params.product.image);
            Image.debugLine("entry/src/main/ets/common/components/ProductItem.ets(20:7)", "entry");
            Image.width('100%');
            Image.aspectRatio(1);
            Image.borderRadius(12);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.params.product.name);
            Text.debugLine("entry/src/main/ets/common/components/ProductItem.ets(26:7)", "entry");
            Text.fontSize(16);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Constants.TEXT_PRIMARY_COLOR);
            Text.margin({ top: 8 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`¥${this.params.product.price}`);
            Text.debugLine("entry/src/main/ets/common/components/ProductItem.ets(32:7)", "entry");
            Text.fontSize(14);
            Text.fontColor(Constants.PRIMARY_COLOR);
            Text.margin({ top: 4 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('查看详情');
            Button.debugLine("entry/src/main/ets/common/components/ProductItem.ets(37:7)", "entry");
            Button.size({ width: '100%', height: 36 });
            Button.backgroundColor(Constants.PRIMARY_COLOR);
            Button.fontColor(Color.White);
            Button.margin({ top: 8 });
            Button.onClick(() => this.params.onProductClick(this.params.product));
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
