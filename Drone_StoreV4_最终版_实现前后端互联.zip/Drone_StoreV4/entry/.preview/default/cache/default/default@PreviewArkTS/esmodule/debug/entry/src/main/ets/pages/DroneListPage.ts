if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface DroneListPage_Params {
    drones?: Drone[];
    errorMsg?: string;
}
import http from "@ohos:net.http";
import router from "@ohos:router";
interface Drone {
    id: number;
    name: string;
    model: string;
    price: number;
}
class DroneListPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__drones = new ObservedPropertyObjectPU([], this, "drones");
        this.__errorMsg = new ObservedPropertySimplePU('', this, "errorMsg");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: DroneListPage_Params) {
        if (params.drones !== undefined) {
            this.drones = params.drones;
        }
        if (params.errorMsg !== undefined) {
            this.errorMsg = params.errorMsg;
        }
    }
    updateStateVars(params: DroneListPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__drones.purgeDependencyOnElmtId(rmElmtId);
        this.__errorMsg.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__drones.aboutToBeDeleted();
        this.__errorMsg.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __drones: ObservedPropertyObjectPU<Drone[]>;
    get drones() {
        return this.__drones.get();
    }
    set drones(newValue: Drone[]) {
        this.__drones.set(newValue);
    }
    private __errorMsg: ObservedPropertySimplePU<string>;
    get errorMsg() {
        return this.__errorMsg.get();
    }
    set errorMsg(newValue: string) {
        this.__errorMsg.set(newValue);
    }
    aboutToAppear() {
        this.fetchDroneList();
    }
    fetchDroneList() {
        const httpRequest = http.createHttp();
        httpRequest.request('http://192.168.43.125:8000/drones', {
            method: http.RequestMethod.GET,
            expectDataType: http.HttpDataType.STRING
        }, (err, data) => {
            if (!err && typeof data.result === 'string') {
                try {
                    this.drones = JSON.parse(data.result) as Drone[];
                    this.errorMsg = '';
                }
                catch (e) {
                    this.errorMsg = '数据解析错误';
                    this.drones = [];
                }
            }
            else {
                this.errorMsg = '请求失败';
                this.drones = [];
            }
        });
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 12 });
            Column.debugLine("entry/src/main/ets/pages/DroneListPage.ets(47:5)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('无人机列表');
            Text.debugLine("entry/src/main/ets/pages/DroneListPage.ets(48:7)", "entry");
            Text.fontSize(24);
            Text.fontWeight(FontWeight.Bold);
            Text.margin({ bottom: 10 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.errorMsg !== '') {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.errorMsg);
                        Text.debugLine("entry/src/main/ets/pages/DroneListPage.ets(54:9)", "entry");
                        Text.fontColor(Color.Red);
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('返回登录');
            Button.debugLine("entry/src/main/ets/pages/DroneListPage.ets(55:8)", "entry");
            Button.onClick(() => {
                router.back();
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const drone = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create({ space: 6 });
                    Column.debugLine("entry/src/main/ets/pages/DroneListPage.ets(61:9)", "entry");
                    Column.padding(10);
                    Column.border({ width: 1, color: Color.Gray });
                    Column.margin({ bottom: 8 });
                    Column.backgroundColor(Color.White);
                    Column.borderRadius(8);
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(`型号：${drone.model}`);
                    Text.debugLine("entry/src/main/ets/pages/DroneListPage.ets(62:11)", "entry");
                    Text.fontSize(18);
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(`名称：${drone.name}`);
                    Text.debugLine("entry/src/main/ets/pages/DroneListPage.ets(63:11)", "entry");
                }, Text);
                Text.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(`价格：￥${drone.price}`);
                    Text.debugLine("entry/src/main/ets/pages/DroneListPage.ets(64:11)", "entry");
                }, Text);
                Text.pop();
                Column.pop();
            };
            this.forEachUpdateFunction(elmtId, this.drones, forEachItemGenFunction, (drone: Drone) => drone.id.toString(), false, false);
        }, ForEach);
        ForEach.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "DroneListPage";
    }
}
registerNamedRoute(() => new DroneListPage(undefined, {}), "", { bundleName: "com.example.droneStore", moduleName: "entry", pagePath: "pages/DroneListPage", pageFullPath: "entry/src/main/ets/pages/DroneListPage", integratedHsp: "false", moduleType: "followWithHap" });
