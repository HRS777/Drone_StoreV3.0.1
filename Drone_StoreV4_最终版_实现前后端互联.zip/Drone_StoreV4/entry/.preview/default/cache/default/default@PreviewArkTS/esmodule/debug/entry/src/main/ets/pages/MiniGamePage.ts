if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface MiniGamePage_Params {
    playing?: boolean;
    droneY?: number;
    obstacleX?: number;
    score?: number;
    timer?: number;
}
import router from "@ohos:router";
import { GameStyles } from "@normalized:N&&&entry/src/main/ets/pages/GameStyles&";
class MiniGamePage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__playing = new ObservedPropertySimplePU(false, this, "playing");
        this.__droneY = new ObservedPropertySimplePU(200, this, "droneY");
        this.__obstacleX = new ObservedPropertySimplePU(400, this, "obstacleX");
        this.__score = new ObservedPropertySimplePU(0, this, "score");
        this.timer = 0;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: MiniGamePage_Params) {
        if (params.playing !== undefined) {
            this.playing = params.playing;
        }
        if (params.droneY !== undefined) {
            this.droneY = params.droneY;
        }
        if (params.obstacleX !== undefined) {
            this.obstacleX = params.obstacleX;
        }
        if (params.score !== undefined) {
            this.score = params.score;
        }
        if (params.timer !== undefined) {
            this.timer = params.timer;
        }
    }
    updateStateVars(params: MiniGamePage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__playing.purgeDependencyOnElmtId(rmElmtId);
        this.__droneY.purgeDependencyOnElmtId(rmElmtId);
        this.__obstacleX.purgeDependencyOnElmtId(rmElmtId);
        this.__score.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__playing.aboutToBeDeleted();
        this.__droneY.aboutToBeDeleted();
        this.__obstacleX.aboutToBeDeleted();
        this.__score.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __playing: ObservedPropertySimplePU<boolean>;
    get playing() {
        return this.__playing.get();
    }
    set playing(newValue: boolean) {
        this.__playing.set(newValue);
    }
    private __droneY: ObservedPropertySimplePU<number>;
    get droneY() {
        return this.__droneY.get();
    }
    set droneY(newValue: number) {
        this.__droneY.set(newValue);
    }
    private __obstacleX: ObservedPropertySimplePU<number>;
    get obstacleX() {
        return this.__obstacleX.get();
    }
    set obstacleX(newValue: number) {
        this.__obstacleX.set(newValue);
    }
    private __score: ObservedPropertySimplePU<number>;
    get score() {
        return this.__score.get();
    }
    set score(newValue: number) {
        this.__score.set(newValue);
    }
    private timer: number;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 10 });
            Column.debugLine("entry/src/main/ets/pages/MiniGamePage.ets(15:5)", "entry");
            Column.padding(20);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('🚁 DroneGame');
            Text.debugLine("entry/src/main/ets/pages/MiniGamePage.ets(16:7)", "entry");
            Text.fontSize(GameStyles.FontSize.Title);
            Text.fontWeight(FontWeight.Bold);
            Text.padding(GameStyles.Spacing.TitlePadding);
            Text.textAlign(TextAlign.Center);
            Text.fontColor(GameStyles.Color.Title);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (!this.playing) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('🎮 开始游戏');
                        Button.debugLine("entry/src/main/ets/pages/MiniGamePage.ets(25:9)", "entry");
                        Button.fontSize(GameStyles.FontSize.Button);
                        Button.fontColor(GameStyles.Color.ButtonText);
                        Button.backgroundColor(GameStyles.Color.Button);
                        Button.borderRadius(GameStyles.Radius.Button);
                        Button.margin(GameStyles.Spacing.ButtonMargin);
                        Button.width('60%');
                        Button.height(50);
                        Button.onClick(() => this.startGame());
                    }, Button);
                    Button.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.playing) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/MiniGamePage.ets(37:9)", "entry");
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Stack.create();
                        Stack.debugLine("entry/src/main/ets/pages/MiniGamePage.ets(38:11)", "entry");
                        Stack.clip(true);
                        Stack.border({ radius: 8 });
                    }, Stack);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Rect.create();
                        Rect.debugLine("entry/src/main/ets/pages/MiniGamePage.ets(39:13)", "entry");
                        Rect.width('100%');
                        Rect.height(400);
                        Rect.backgroundColor('#ffd965a2');
                        Rect.onClick(() => this.jump());
                    }, Rect);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create({ "id": 33554450, "type": 20000, params: [], "bundleName": "com.example.droneStore", "moduleName": "entry" });
                        Image.debugLine("entry/src/main/ets/pages/MiniGamePage.ets(45:13)", "entry");
                        Image.width(40);
                        Image.height(40);
                        Image.position({ x: 60, y: this.droneY });
                    }, Image);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Rect.create();
                        Rect.debugLine("entry/src/main/ets/pages/MiniGamePage.ets(50:13)", "entry");
                        Rect.width(30);
                        Rect.height(100);
                        Rect.position({ x: this.obstacleX, y: 250 });
                        Rect.backgroundColor(Color.Red);
                    }, Rect);
                    Stack.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(`当前分数：${this.score}`);
                        Text.debugLine("entry/src/main/ets/pages/MiniGamePage.ets(59:11)", "entry");
                        Text.fontSize(20);
                        Text.margin({ top: 16 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    startGame() {
        this.playing = true;
        this.droneY = 200;
        this.obstacleX = 400;
        this.score = 0;
        this.timer = setInterval(() => {
            this.droneY += 5;
            this.obstacleX -= 5;
            if (this.obstacleX < -30) {
                this.obstacleX = 400;
                this.score += 1;
            }
            // 碰撞检测
            if (this.droneY > 360 || this.droneY < 0) {
                this.gameOver();
            }
            if (this.obstacleX < 100 && this.obstacleX > 50 && this.droneY > 250) {
                this.gameOver();
            }
        }, 50);
    }
    jump() {
        this.droneY -= 30;
    }
    gameOver() {
        clearInterval(this.timer);
        this.playing = false;
        AlertDialog.show({
            title: '游戏结束 🎮',
            message: `你的得分是：${this.score}`,
            primaryButton: {
                value: '再来一次',
                action: () => this.startGame()
            },
            secondaryButton: {
                value: '返回首页',
                action: () => router.back()
            }
        });
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "MiniGamePage";
    }
}
if (getPreviewComponentFlag()) {
    storePreviewComponents(1, "MiniGamePage", new MiniGamePage(undefined, {}));
    previewComponent();
}
else {
    registerNamedRoute(() => new MiniGamePage(undefined, {}), "", { bundleName: "com.example.droneStore", moduleName: "entry", pagePath: "pages/MiniGamePage", pageFullPath: "entry/src/main/ets/pages/MiniGamePage", integratedHsp: "false", moduleType: "followWithHap" });
}
