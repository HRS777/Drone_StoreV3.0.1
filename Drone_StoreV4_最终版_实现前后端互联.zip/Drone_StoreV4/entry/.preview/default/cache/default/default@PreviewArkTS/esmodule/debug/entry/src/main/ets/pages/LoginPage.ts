if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface LoginPage_Params {
    username?: string;
    password?: string;
    result?: string;
}
import http from "@ohos:net.http";
import router from "@ohos:router";
interface GeneratedTypeLiteralInterface_1 {
    result: string;
}
class LoginPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__username = new ObservedPropertySimplePU('', this, "username");
        this.__password = new ObservedPropertySimplePU('', this, "password");
        this.__result = new ObservedPropertySimplePU('', this, "result");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: LoginPage_Params) {
        if (params.username !== undefined) {
            this.username = params.username;
        }
        if (params.password !== undefined) {
            this.password = params.password;
        }
        if (params.result !== undefined) {
            this.result = params.result;
        }
    }
    updateStateVars(params: LoginPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__username.purgeDependencyOnElmtId(rmElmtId);
        this.__password.purgeDependencyOnElmtId(rmElmtId);
        this.__result.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__username.aboutToBeDeleted();
        this.__password.aboutToBeDeleted();
        this.__result.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __username: ObservedPropertySimplePU<string>;
    get username() {
        return this.__username.get();
    }
    set username(newValue: string) {
        this.__username.set(newValue);
    }
    private __password: ObservedPropertySimplePU<string>;
    get password() {
        return this.__password.get();
    }
    set password(newValue: string) {
        this.__password.set(newValue);
    }
    private __result: ObservedPropertySimplePU<string>;
    get result() {
        return this.__result.get();
    }
    set result(newValue: string) {
        this.__result.set(newValue);
    }
    login() {
        let httpRequest = http.createHttp();
        httpRequest.request('http://192.168.43.125:8000/login?username=' + this.username + '&password=' + this.password, {
            method: http.RequestMethod.GET,
            extraData: {},
            expectDataType: http.HttpDataType.STRING
        }, (err, data) => {
            if (!err && typeof data.result === 'string') {
                let json: GeneratedTypeLiteralInterface_1 = JSON.parse(data.result);
                if (json.result === 'success') {
                    this.result = '登录成功';
                    router.pushUrl({ url: 'pages/DroneListPage' });
                }
                else {
                    this.result = '账号或密码错误';
                }
            }
            else {
                this.result = '请求失败';
            }
        });
    }
    initialRender() {
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "LoginPage";
    }
}
export { LoginPage };
registerNamedRoute(() => new LoginPage(undefined, {}), "", { bundleName: "com.example.droneStore", moduleName: "entry", pagePath: "pages/LoginPage", pageFullPath: "entry/src/main/ets/pages/LoginPage", integratedHsp: "false", moduleType: "followWithHap" });
