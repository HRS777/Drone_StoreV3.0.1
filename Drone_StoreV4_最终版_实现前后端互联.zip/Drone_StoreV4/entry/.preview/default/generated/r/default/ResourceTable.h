/*
 * Copyright (c) 2023 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef RESOURCE_TABLE_H
#define RESOURCE_TABLE_H

#include<stdint.h>

namespace OHOS {
const int32_t STRING_ENTRYABILITY_DESC = 0x01000014;
const int32_t STRING_ENTRYABILITY_LABEL = 0x01000015;
const int32_t STRING_APP_NAME = 0x01000003;
const int32_t STRING_FORGOT_PASSWORD = 0x02000005;
const int32_t STRING_LOGIN = 0x02000006;
const int32_t STRING_LOGIN_FAILED = 0x02000007;
const int32_t STRING_LOGIN_SUCCESS = 0x02000008;
const int32_t STRING_LOGIN_TITLE = 0x02000009;
const int32_t STRING_MODULE_DESC = 0x01000016;
const int32_t STRING_PAGE_SHOW = 0x0200000f;
const int32_t STRING_PASSWORD = 0x0200000a;
const int32_t STRING_PASSWORD_TOO_SHORT = 0x0200000b;
const int32_t STRING_SETTINGS = 0x02000010;
const int32_t STRING_SHOW_PASSWORD = 0x0200000c;
const int32_t STRING_USERNAME = 0x0200000d;
const int32_t STRING_USERNAME_EMPTY = 0x0200000e;
const int32_t STRING_WELCOME = 0x02000013;
const int32_t COLOR_BACKGROUND_WHITE = 0x02000000;
const int32_t COLOR_ERROR_RED = 0x02000001;
const int32_t COLOR_LINK_BLUE = 0x02000002;
const int32_t COLOR_PRIMARY_BLUE = 0x02000003;
const int32_t COLOR_START_WINDOW_BACKGROUND = 0x01000008;
const int32_t COLOR_TEXT_PRIMARY = 0x02000004;
const int32_t FLOAT_PAGE_TEXT_FONT_SIZE = 0x01000006;
const int32_t MEDIA_APP_ICON = 0x01000005;
const int32_t MEDIA_BACKGROUND = 0x01000000;
const int32_t MEDIA_DRONE1 = 0x01000018;
const int32_t MEDIA_DRONE2 = 0x0100000f;
const int32_t MEDIA_DRONE3 = 0x01000009;
const int32_t MEDIA_DRONE4 = 0x0100000d;
const int32_t MEDIA_DRONE_ICON = 0x02000012;
const int32_t MEDIA_FOREGROUND = 0x01000002;
const int32_t MEDIA_IC_BACK = 0x01000017;
const int32_t MEDIA_IC_CHECK = 0x0100000a;
const int32_t MEDIA_IC_PARAMS = 0x01000012;
const int32_t MEDIA_IC_PARAMS_SELECTED = 0x01000011;
const int32_t MEDIA_IC_SETTINGS = 0x0100000b;
const int32_t MEDIA_IC_SHARE = 0x01000013;
const int32_t MEDIA_IC_STORE_SELECTED = 0x01000007;
const int32_t MEDIA_ICON = 0x01000010;
const int32_t MEDIA_LAYERED_IMAGE = 0x01000001;
const int32_t MEDIA_LOGIN_BG = 0x02000011;
const int32_t MEDIA_STARTICON = 0x01000004;
const int32_t PROFILE_BACKUP_CONFIG = 0x0100000e;
const int32_t PROFILE_MAIN_PAGES = 0x01000019;
}
#endif