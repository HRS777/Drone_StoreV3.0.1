if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
import promptAction from '@ohos:promptAction';
import router from '@ohos:router';
class Login extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__username = new ObservedPropertySimplePU('1', this, "username");
        this.__password = new ObservedPropertySimplePU('88888888', this, "password");
        this.__showPassword = new ObservedPropertySimplePU(false, this, "showPassword");
        this.__errorMessage = new ObservedPropertySimplePU('', this, "errorMessage");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params) {
        if (params.username !== undefined) {
            this.username = params.username;
        }
        if (params.password !== undefined) {
            this.password = params.password;
        }
        if (params.showPassword !== undefined) {
            this.showPassword = params.showPassword;
        }
        if (params.errorMessage !== undefined) {
            this.errorMessage = params.errorMessage;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__username.purgeDependencyOnElmtId(rmElmtId);
        this.__password.purgeDependencyOnElmtId(rmElmtId);
        this.__showPassword.purgeDependencyOnElmtId(rmElmtId);
        this.__errorMessage.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__username.aboutToBeDeleted();
        this.__password.aboutToBeDeleted();
        this.__showPassword.aboutToBeDeleted();
        this.__errorMessage.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get username() {
        return this.__username.get();
    }
    set username(newValue) {
        this.__username.set(newValue);
    }
    get password() {
        return this.__password.get();
    }
    set password(newValue) {
        this.__password.set(newValue);
    }
    get showPassword() {
        return this.__showPassword.get();
    }
    set showPassword(newValue) {
        this.__showPassword.set(newValue);
    }
    get errorMessage() {
        return this.__errorMessage.get();
    }
    set errorMessage(newValue) {
        this.__errorMessage.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("login/src/main/ets/components/Login.ets(14:5)", "login");
            Column.width('100%');
            Column.height('100%');
            Column.padding(20);
            Column.backgroundColor({ "id": 50331680, "type": 10001, params: [], "bundleName": "com.example.droneStore", "moduleName": "login" });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create({ "id": 50331669, "type": 10003, params: [], "bundleName": "com.example.droneStore", "moduleName": "login" });
            Text.debugLine("login/src/main/ets/components/Login.ets(16:7)", "login");
            Text.fontSize(24);
            Text.fontColor({ "id": 50331685, "type": 10001, params: [], "bundleName": "com.example.droneStore", "moduleName": "login" });
            Text.margin({ top: 40, bottom: 60 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: { "id": 50331674, "type": 10003, params: [], "bundleName": "com.example.droneStore", "moduleName": "login" } });
            TextInput.debugLine("login/src/main/ets/components/Login.ets(21:7)", "login");
            TextInput.width('80%');
            TextInput.height(50);
            TextInput.type(InputType.Normal);
            TextInput.onChange((value) => {
                this.username = value;
                this.clearError();
            });
            TextInput.margin({ bottom: 20 });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: { "id": 50331671, "type": 10003, params: [], "bundleName": "com.example.droneStore", "moduleName": "login" } });
            TextInput.debugLine("login/src/main/ets/components/Login.ets(32:7)", "login");
            TextInput.width('80%');
            TextInput.height(50);
            TextInput.type(this.showPassword ? InputType.Normal : InputType.Password);
            TextInput.onChange((value) => {
                this.password = value;
                this.clearError();
            });
            TextInput.margin({ bottom: 10 });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("login/src/main/ets/components/Login.ets(42:7)", "login");
            Row.width('80%');
            Row.justifyContent(FlexAlign.Start);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Checkbox.create();
            Checkbox.debugLine("login/src/main/ets/components/Login.ets(43:9)", "login");
            Checkbox.select(this.showPassword);
            Checkbox.onChange((checked) => {
                this.showPassword = checked;
            });
        }, Checkbox);
        Checkbox.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create({ "id": 50331673, "type": 10003, params: [], "bundleName": "com.example.droneStore", "moduleName": "login" });
            Text.debugLine("login/src/main/ets/components/Login.ets(48:9)", "login");
            Text.fontSize(14);
            Text.margin({ left: 8 });
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.errorMessage) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.errorMessage);
                        Text.debugLine("login/src/main/ets/components/Login.ets(57:9)", "login");
                        Text.fontSize(14);
                        Text.fontColor({ "id": 50331681, "type": 10001, params: [], "bundleName": "com.example.droneStore", "moduleName": "login" });
                        Text.margin({ top: 10 });
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel({ "id": 50331666, "type": 10003, params: [], "bundleName": "com.example.droneStore", "moduleName": "login" }, { type: ButtonType.Capsule });
            Button.debugLine("login/src/main/ets/components/Login.ets(64:7)", "login");
            Button.width('60%');
            Button.height(45);
            Button.margin({ top: 40 });
            Button.backgroundColor({ "id": 50331683, "type": 10001, params: [], "bundleName": "com.example.droneStore", "moduleName": "login" });
            Button.onClick(() => this.handleLogin());
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create({ "id": 50331665, "type": 10003, params: [], "bundleName": "com.example.droneStore", "moduleName": "login" });
            Text.debugLine("login/src/main/ets/components/Login.ets(71:7)", "login");
            Text.fontSize(14);
            Text.fontColor({ "id": 50331682, "type": 10001, params: [], "bundleName": "com.example.droneStore", "moduleName": "login" });
            Text.margin({ top: 20 });
        }, Text);
        Text.pop();
        Column.pop();
    }
    async handleLogin() {
        if (!this.validateForm())
            return;
        AppStorage.setOrCreate('token', 'mock_token');
        router.replaceUrl({ url: 'pages/Index' });
        promptAction.showToast({
            message: { "id": 50331668, "type": 10003, params: [], "bundleName": "com.example.droneStore", "moduleName": "login" },
            duration: 2000
        });
    }
    validateForm() {
        if (this.username.trim().length === 0) {
            this.errorMessage = { "id": 50331675, "type": 10003, params: [], "bundleName": "com.example.droneStore", "moduleName": "login" }.toString();
            promptAction.showToast({
                message: { "id": 50331675, "type": 10003, params: [], "bundleName": "com.example.droneStore", "moduleName": "login" },
                duration: 2000
            });
            return false;
        }
        if (this.password.length < 8) {
            this.errorMessage = { "id": 50331672, "type": 10003, params: [], "bundleName": "com.example.droneStore", "moduleName": "login" }.toString();
            promptAction.showToast({
                message: { "id": 50331672, "type": 10003, params: [], "bundleName": "com.example.droneStore", "moduleName": "login" },
                duration: 2000
            });
            return false;
        }
        return true;
    }
    clearError() {
        this.errorMessage = '';
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName() {
        return "Login";
    }
}
if (getPreviewComponentFlag()) {
    storePreviewComponents(1, "Login", new Login(undefined, {}));
    previewComponent();
}
else {
    registerNamedRoute(() => new Login(undefined, {}), "", { bundleName: "com.example.droneStore", moduleName: "login", pagePath: "components/Login", pageFullPath: "login/src/main/ets/components/Login", integratedHsp: "false", moduleType: "followWithHap" });
}
//# sourceMappingURL=Login.js.map