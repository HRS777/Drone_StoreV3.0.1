/*
 * Copyright (c) 2023 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef RESOURCE_TABLE_H
#define RESOURCE_TABLE_H

#include<stdint.h>

namespace OHOS {
const int32_t STRING_ENTRYABILITY_DESC = 0x0300000e;
const int32_t STRING_ENTRYABILITY_LABEL = 0x0300000f;
const int32_t STRING_APP_NAME = 0x03000010;
const int32_t STRING_FORGOT_PASSWORD = 0x03000011;
const int32_t STRING_LOGIN = 0x03000012;
const int32_t STRING_LOGIN_FAILED = 0x03000013;
const int32_t STRING_LOGIN_SUCCESS = 0x03000014;
const int32_t STRING_LOGIN_TITLE = 0x03000015;
const int32_t STRING_MODULE_DESC = 0x03000016;
const int32_t STRING_PASSWORD = 0x03000017;
const int32_t STRING_PASSWORD_TOO_SHORT = 0x03000018;
const int32_t STRING_SHOW_PASSWORD = 0x03000019;
const int32_t STRING_USERNAME = 0x0300001a;
const int32_t STRING_USERNAME_EMPTY = 0x0300001b;
const int32_t COLOR_BACKGROUND_WHITE = 0x03000020;
const int32_t COLOR_ERROR_RED = 0x03000021;
const int32_t COLOR_LINK_BLUE = 0x03000022;
const int32_t COLOR_PRIMARY_BLUE = 0x03000023;
const int32_t COLOR_START_WINDOW_BACKGROUND = 0x03000024;
const int32_t COLOR_TEXT_PRIMARY = 0x03000025;
const int32_t FLOAT_PAGE_TEXT_FONT_SIZE = 0x03000001;
const int32_t MEDIA_APP_ICON = 0x0300001e;
const int32_t MEDIA_BACKGROUND = 0x03000005;
const int32_t MEDIA_DRONE1 = 0x03000002;
const int32_t MEDIA_DRONE2 = 0x03000000;
const int32_t MEDIA_DRONE3 = 0x0300000d;
const int32_t MEDIA_DRONE4 = 0x0300000b;
const int32_t MEDIA_FOREGROUND = 0x0300001c;
const int32_t MEDIA_IC_BACK = 0x03000004;
const int32_t MEDIA_IC_CHECK = 0x0300000a;
const int32_t MEDIA_IC_PARAMS = 0x03000007;
const int32_t MEDIA_IC_PARAMS_SELECTED = 0x03000006;
const int32_t MEDIA_IC_SETTINGS = 0x03000009;
const int32_t MEDIA_IC_SHARE = 0x0300000c;
const int32_t MEDIA_IC_STORE_SELECTED = 0x03000008;
const int32_t MEDIA_ICON = 0x0300001f;
const int32_t MEDIA_LAYERED_IMAGE = 0x0300001d;
const int32_t MEDIA_STARTICON = 0x03000003;
}
#endif